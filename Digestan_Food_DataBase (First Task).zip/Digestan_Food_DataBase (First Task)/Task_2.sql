select p.defaultOfferType, count(*) as order_count
From providers p
join orders o on p.id = o.providerId
GROUP by p.defaultOfferType
order by order_count DESC
LIMIT 2;