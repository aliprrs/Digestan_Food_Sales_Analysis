SELECT u.id, u.registeredDate, SUM(o.sales) AS total_sales
from users u
join orders o on u.id = o.userId
WHERE u.registeredDate between '2023-01-01' and '2023-12-31'
group by u.id, u.registeredDate
order by total_sales DESC
limit 10;